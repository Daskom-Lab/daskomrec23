@yield('footer')
<section id="footer">
    <footer class="container">
    <div class="d-flex justify-content-center">
      <div>
        <span style="font-size: 13px">Official Daskom Lab Recruitment 2022</span>
      </div>
    </div>
    </footer>
</section>